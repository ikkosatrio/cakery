<?php

class Globals {

    const URL_PROPERTY = "https://marketingproperti.com/";
 
    const TYPE_PROPERTY = array(
        'secondary' => "Secondary",
        'primary' => "Primary",
    );

    const TYPE_TRANSACTION = array(
        'sale' => "Sale",
        'rent' => "Rent",
    );

    const CERTIFICATE_PROPERTY = array(
        'shm' => "Sertifikat Hak Milik (SHM)",
        'shgb' => "Sertifikat Hak Guna Bangunan (SHGB)",
        'shsrs' => "Sertifikat Hak Satuan Rumah Susun (SHSRS)",
        'girik' => "Girik",
        'ajb' => "Akta Jual Beli (AJB)",
    );
}
