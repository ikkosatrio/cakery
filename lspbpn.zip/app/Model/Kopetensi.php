<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Kopetensi extends Model
{
    protected $guarded = [];
}
