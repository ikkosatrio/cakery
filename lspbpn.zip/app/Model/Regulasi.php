<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Regulasi extends Model
{
    protected $table = 'contoh_regulasis';
    protected $guarded = [];
}
