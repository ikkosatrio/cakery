<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class KopetensiDetail extends Model
{
    protected $guarded = [];
}
