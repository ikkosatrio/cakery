<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Group_user extends Model
{
    protected $guarded = [];
}
