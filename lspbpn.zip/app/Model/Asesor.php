<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Asesor extends Model
{
    protected $guarded = [];
    protected $dates = ['expired_date'];
}
