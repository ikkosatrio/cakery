<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FAQ extends Model
{
    protected $table = 'faqs';
    protected $guarded = [];
    
}
